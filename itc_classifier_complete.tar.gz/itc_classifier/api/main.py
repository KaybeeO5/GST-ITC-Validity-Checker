"""
FastAPI Backend for ITC Denial Classification System
RESTful API for Narentis integration
"""

from fastapi import FastAPI, UploadFile, File, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from datetime import datetime
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from models.classifier import ITCDenialClassifier
from api.defence_db import DefenceDatabase, generate_action_plan
from loguru import logger

# Initialize FastAPI app
app = FastAPI(
    title="ITC Denial Classification API",
    description="AI-powered classification and legal defence suggestion system for GST ITC denials",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware for Narentis integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify actual Narentis domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize ML model and knowledge base (loaded once at startup)
classifier = None
defence_db = None

@app.on_event("startup")
async def startup_event():
    """Load ML model and knowledge base on startup"""
    global classifier, defence_db
    
    logger.info("Starting ITC Denial Classification API...")
    
    try:
        classifier = ITCDenialClassifier()
        logger.success("✓ Classifier model loaded")
    except Exception as e:
        logger.error(f"Failed to load classifier: {e}")
        # Continue with placeholder - will handle in endpoints
    
    try:
        defence_db = DefenceDatabase()
        logger.success("✓ Defence database loaded")
    except Exception as e:
        logger.error(f"Failed to load defence database: {e}")
        # Continue with template database
    
    logger.success("API ready to serve requests")


# ============================================================================
# REQUEST/RESPONSE MODELS
# ============================================================================

class DenialInput(BaseModel):
    """Input for classification endpoint"""
    case_id: str = Field(..., description="Unique case identifier")
    denial_text: str = Field(..., min_length=10, description="Denial reason text from notice")
    notice_date: Optional[str] = Field(None, description="Notice date (YYYY-MM-DD)")
    amount: Optional[float] = Field(None, ge=0, description="ITC amount at stake")
    
    class Config:
        schema_extra = {
            "example": {
                "case_id": "CASE-2024-001",
                "denial_text": "ITC claim denied as supplier has not filed GSTR-1 for the relevant tax period",
                "notice_date": "2024-01-15",
                "amount": 150000
            }
        }


class CaseLawInfo(BaseModel):
    """Case law information"""
    case: str
    citation: Optional[str] = None
    court: Optional[str] = None
    year: Optional[int] = None
    outcome: Optional[str] = None
    ratio: str
    doc_path: Optional[str] = None


class DefenceOutput(BaseModel):
    """Output from classification endpoint"""
    case_id: str
    primary_category: str
    secondary_category: Optional[str] = None
    confidence_score: float
    applicable_sections: List[str]
    supporting_circulars: List[str]
    case_law: List[CaseLawInfo]
    defence_arguments: List[str]
    evidence_checklist: List[str]
    next_steps: List[str]
    success_rate: str
    processing_time_ms: float


class CategoryInfo(BaseModel):
    """Information about a denial category"""
    name: str
    description: str
    total_cases: int
    sections: List[str]
    success_rate: str


class KnowledgeBaseStats(BaseModel):
    """Statistics about the knowledge base"""
    total_categories: int
    total_cases: int
    total_sections: int
    categories_with_cases: int


# ============================================================================
# API ENDPOINTS
# ============================================================================

@app.get("/")
async def root():
    """API health check and info"""
    return {
        "service": "ITC Denial Classification API",
        "status": "operational",
        "version": "1.0.0",
        "endpoints": {
            "classify": "POST /classify-denial",
            "upload": "POST /upload-notice",
            "categories": "GET /categories",
            "case_law": "GET /case-law/{category}",
            "stats": "GET /stats"
        }
    }


@app.post("/classify-denial", response_model=DefenceOutput)
async def classify_denial(denial: DenialInput):
    """
    Main classification endpoint
    
    Classifies denial text and returns complete defence strategy with case law
    """
    start_time = datetime.now()
    
    try:
        # Step 1: Classify denial text
        logger.info(f"Processing case {denial.case_id}")
        
        if classifier is None:
            raise HTTPException(status_code=503, detail="Classifier not loaded")
        
        categories = classifier.classify(denial.denial_text, top_k=2)
        primary_cat = categories[0][0]
        secondary_cat = categories[1][0] if len(categories) > 1 else None
        confidence = categories[0][1]
        
        logger.info(f"Classified as: {primary_cat} ({confidence:.2%})")
        
        # Step 2: Get defence strategy from knowledge base
        if defence_db is None:
            raise HTTPException(status_code=503, detail="Defence database not loaded")
        
        strategy = defence_db.get_defence_strategy(primary_cat)
        
        # Step 3: Generate action plan
        next_steps = generate_action_plan(
            primary_cat,
            denial.notice_date or datetime.now().strftime("%Y-%m-%d"),
            denial.amount or 0
        )
        
        # Calculate processing time
        processing_time = (datetime.now() - start_time).total_seconds() * 1000
        
        # Step 4: Format response
        return DefenceOutput(
            case_id=denial.case_id,
            primary_category=primary_cat,
            secondary_category=secondary_cat,
            confidence_score=confidence,
            applicable_sections=strategy['sections'],
            supporting_circulars=strategy['circulars'],
            case_law=[CaseLawInfo(**case) for case in strategy['case_law']],
            defence_arguments=strategy['defence_points'],
            evidence_checklist=strategy['evidence_checklist'],
            next_steps=next_steps,
            success_rate=strategy['success_rate'],
            processing_time_ms=round(processing_time, 2)
        )
        
    except Exception as e:
        logger.error(f"Classification failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Classification failed: {str(e)}")


@app.post("/upload-notice")
async def upload_notice_pdf(file: UploadFile = File(...)):
    """
    Upload GST notice PDF/image for automatic text extraction and classification
    
    Note: OCR implementation requires pytesseract and Poppler
    For MVP, this returns a placeholder - implement OCR in production
    """
    if not file.filename.endswith(('.pdf', '.png', '.jpg', '.jpeg')):
        raise HTTPException(status_code=400, detail="File must be PDF or image (PNG, JPG)")
    
    # TODO: Implement actual OCR extraction
    # For now, return placeholder response
    
    return {
        "filename": file.filename,
        "status": "extracted",
        "extracted_text": "Placeholder: Implement OCR extraction in production using pytesseract",
        "message": "OCR feature coming soon. For now, please use /classify-denial with manual text input"
    }


@app.get("/categories", response_model=List[CategoryInfo])
async def get_all_categories():
    """
    Get information about all available denial categories
    """
    if defence_db is None:
        raise HTTPException(status_code=503, detail="Defence database not loaded")
    
    categories = []
    
    for cat_name in defence_db.get_all_categories():
        strategy = defence_db.get_defence_strategy(cat_name)
        
        categories.append(CategoryInfo(
            name=cat_name,
            description=classifier.CATEGORY_DESCRIPTIONS.get(cat_name, ""),
            total_cases=len(strategy['case_law']),
            sections=strategy['sections'],
            success_rate=strategy['success_rate']
        ))
    
    return categories


@app.get("/case-law/{category}")
async def get_case_law_for_category(category: str):
    """
    Get all case law for a specific category
    
    Args:
        category: Denial category name (use /categories to see all)
    """
    if defence_db is None:
        raise HTTPException(status_code=503, detail="Defence database not loaded")
    
    case_law = defence_db.get_case_law_for_category(category)
    
    if not case_law:
        raise HTTPException(status_code=404, detail=f"No case law found for category: {category}")
    
    return {
        "category": category,
        "total_cases": len(case_law),
        "cases": case_law
    }


@app.get("/search/section")
async def search_by_section(section: str = Query(..., description="CGST Act section (e.g., 16(2)(c))")):
    """
    Find all categories applicable to a specific CGST Act section
    """
    if defence_db is None:
        raise HTTPException(status_code=503, detail="Defence database not loaded")
    
    categories = defence_db.search_by_section(section)
    
    return {
        "section": section,
        "applicable_categories": categories,
        "count": len(categories)
    }


@app.get("/search/case")
async def search_by_case_name(case_name: str = Query(..., description="Case name or keyword")):
    """
    Find all categories where a specific case is cited
    """
    if defence_db is None:
        raise HTTPException(status_code=503, detail="Defence database not loaded")
    
    categories = defence_db.search_by_case_name(case_name)
    
    return {
        "case_name": case_name,
        "found_in_categories": categories,
        "count": len(categories)
    }


@app.get("/stats", response_model=KnowledgeBaseStats)
async def get_knowledge_base_stats():
    """
    Get statistics about the knowledge base
    """
    if defence_db is None:
        raise HTTPException(status_code=503, detail="Defence database not loaded")
    
    stats = defence_db.get_statistics()
    
    return KnowledgeBaseStats(**stats)


@app.get("/health")
async def health_check():
    """
    Detailed health check for monitoring
    """
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "classifier_loaded": classifier is not None,
        "defence_db_loaded": defence_db is not None,
        "categories_available": len(defence_db.get_all_categories()) if defence_db else 0
    }


# ============================================================================
# RUN SERVER
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    logger.info("Starting ITC Denial Classification API server...")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,  # Auto-reload on code changes (dev mode)
        log_level="info"
    )
