"""
Legal Defence Database
Maps ITC denial categories to applicable laws, case precedents, and defence strategies

YOU NEED TO POPULATE THIS WITH YOUR 75 DOCUMENTS!
See data/knowledge_base_template.json for structure
"""

from typing import Dict, List
import json
from pathlib import Path
from loguru import logger

class DefenceDatabase:
    """
    Knowledge base of legal defences for each ITC denial category
    """
    
    def __init__(self, knowledge_base_path: str = None):
        """
        Load defence database from JSON file
        
        Args:
            knowledge_base_path: Path to knowledge_base.json
                                If None, uses template with placeholder data
        """
        if knowledge_base_path is None:
            knowledge_base_path = Path(__file__).parent.parent / "data" / "knowledge_base.json"
        
        self.kb_path = Path(knowledge_base_path)
        
        if self.kb_path.exists():
            logger.info(f"Loading knowledge base from {self.kb_path}")
            with open(self.kb_path, 'r', encoding='utf-8') as f:
                self.database = json.load(f)
            logger.success(f"Loaded {len(self.database)} categories")
        else:
            logger.warning(f"Knowledge base not found at {self.kb_path}")
            logger.warning("Using template database - POPULATE WITH YOUR 75 DOCUMENTS!")
            self.database = self._get_template_database()
    
    def get_defence_strategy(self, category: str) -> Dict:
        """
        Get complete defence strategy for a denial category
        
        Args:
            category: ITC denial category name
            
        Returns:
            {
                'category': str,
                'sections': List[str],           # Applicable CGST Act sections
                'circulars': List[str],          # Relevant CBIC circulars
                'case_law': List[Dict],          # Precedent cases
                'defence_points': List[str],     # Key arguments
                'evidence_checklist': List[str], # Required documents
                'success_rate': str              # Historical success indicator
            }
        """
        strategy = self.database.get(category, {})
        
        if not strategy:
            logger.warning(f"No defence strategy found for category: {category}")
            return self._get_default_strategy(category)
        
        return {
            'category': category,
            'sections': strategy.get('sections', []),
            'circulars': strategy.get('circulars', []),
            'case_law': strategy.get('case_law', []),
            'defence_points': strategy.get('defence_points', []),
            'evidence_checklist': strategy.get('evidence_checklist', []),
            'success_rate': strategy.get('success_rate', 'Medium'),
            'notes': strategy.get('notes', '')
        }
    
    def get_case_law_for_category(self, category: str) -> List[Dict]:
        """
        Get all case law for a specific category
        
        Returns:
            List of case dictionaries with full details
        """
        strategy = self.database.get(category, {})
        return strategy.get('case_law', [])
    
    def search_by_section(self, section: str) -> List[str]:
        """
        Find all categories applicable to a CGST Act section
        
        Args:
            section: e.g., "16(2)(c)", "16(4)"
            
        Returns:
            List of category names
        """
        matching_categories = []
        
        for category, data in self.database.items():
            if section in data.get('sections', []):
                matching_categories.append(category)
        
        return matching_categories
    
    def search_by_case_name(self, case_name: str) -> List[str]:
        """
        Find categories where a specific case is cited
        
        Args:
            case_name: Partial case name (e.g., "Abhimaani")
            
        Returns:
            List of category names
        """
        matching_categories = []
        
        for category, data in self.database.items():
            for case in data.get('case_law', []):
                if case_name.lower() in case.get('case', '').lower():
                    matching_categories.append(category)
                    break
        
        return matching_categories
    
    def get_all_categories(self) -> List[str]:
        """Get list of all categories in database"""
        return list(self.database.keys())
    
    def get_statistics(self) -> Dict:
        """Get statistics about knowledge base"""
        total_cases = sum(
            len(data.get('case_law', []))
            for data in self.database.values()
        )
        
        total_sections = len(set(
            section
            for data in self.database.values()
            for section in data.get('sections', [])
        ))
        
        return {
            'total_categories': len(self.database),
            'total_cases': total_cases,
            'total_sections': total_sections,
            'categories_with_cases': sum(
                1 for data in self.database.values()
                if data.get('case_law')
            )
        }
    
    def _get_default_strategy(self, category: str) -> Dict:
        """Fallback strategy when category not in database"""
        return {
            'category': category,
            'sections': ['16(2)'],
            'circulars': [],
            'case_law': [],
            'defence_points': [
                'Review specific facts of the case',
                'Gather all supporting documentation',
                'Consult with GST expert for category-specific guidance'
            ],
            'evidence_checklist': [
                'Original tax invoice',
                'Proof of payment',
                'Goods/services receipt proof'
            ],
            'success_rate': 'Unknown',
            'notes': 'Category not yet documented in knowledge base'
        }
    
    def _get_template_database(self) -> Dict:
        """
        Template database structure
        YOU MUST REPLACE THIS WITH YOUR ACTUAL 75 DOCUMENTS DATA!
        """
        return {
            "Supplier Non-Filing": {
                "sections": ["16(2)(c)", "16(2)(aa)"],
                "circulars": [
                    "Circular 183/15/2022-GST - Para 5: ITC not deniable solely on supplier's non-filing"
                ],
                "case_law": [
                    {
                        "case": "LGW Industries Ltd vs. CCT (Calcutta HC, 2021)",
                        "citation": "2021 (12) TMI 248",
                        "court": "Calcutta High Court",
                        "year": 2021,
                        "outcome": "Taxpayer Favorable",
                        "ratio": "ITC cannot be denied solely based on supplier's non-filing if transaction is genuine and recipient has complied with Section 16(2) conditions",
                        "doc_path": "case_law/lgw_industries_2021.pdf",
                        "relevant_paras": [15, 18, 22]
                    },
                    {
                        "case": "Abhimaani Structures (P) Ltd vs. State of Karnataka (Karnataka HC, 2025)",
                        "citation": "2025 (1) TMI 1266",
                        "court": "Karnataka High Court",
                        "year": 2025,
                        "outcome": "Taxpayer Favorable",
                        "ratio": "Procedural lapse by supplier cannot deny ITC to recipient who has complied with all Section 16(2) requirements. Follows Circular 183 interpretation.",
                        "doc_path": "case_law/abhimaani_structures_2025.pdf",
                        "relevant_paras": [12, 19, 25]
                    }
                    # ADD YOUR OTHER CASES HERE FROM YOUR 75 DOCUMENTS
                ],
                "defence_points": [
                    "Recipient has fulfilled all conditions under Section 16(2) - possession of tax invoice, goods/services received, tax reflected in books of account",
                    "Supplier's non-filing is beyond recipient's control and is a procedural lapse by third party (Circular 183/15/2022-GST interpretation)",
                    "Transaction genuineness can be proved through payment records, delivery challans, e-way bills, stock registers",
                    "Cite LGW Industries (Calcutta HC) and Karnataka High Court precedent chain (Abhimaani, Karibasappa, Guru Mahesh)",
                    "Burden on department to prove supply was not genuine, not just procedural non-compliance"
                ],
                "evidence_checklist": [
                    "Tax invoice copy with all mandatory details (GSTIN, HSN/SAC, amount, tax breakup)",
                    "Payment proof - bank statement showing payment to supplier, TDS certificate if applicable",
                    "Goods receipt/service completion proof - delivery challan, LR copy, GRN, work completion certificate",
                    "Supplier's GSTIN validity certificate from GST portal",
                    "E-way bill copy (for goods above ₹50,000)",
                    "Stock register/consumption records showing utilization",
                    "Copy of Circular 183/15/2022-GST",
                    "Certified copies of LGW Industries and Abhimaani judgments"
                ],
                "success_rate": "High",
                "notes": "Strong judicial backing post-Circular 183. Karnataka HC has created robust precedent chain."
            },
            
            "Time-Barred Claims": {
                "sections": ["16(4)", "16(5)"],
                "circulars": [
                    "Circular 183/15/2022-GST - Para 6: Clarification on time limits"
                ],
                "case_law": [
                    {
                        "case": "Abhimaani Structures (P) Ltd (Karnataka HC, 2025)",
                        "citation": "2025 (1) TMI 1266",
                        "court": "Karnataka High Court",
                        "year": 2025,
                        "outcome": "Taxpayer Favorable",
                        "ratio": "Time limit under Section 16(4) can be extended if taxpayer had bona fide belief based on statutory interpretation and reasonable cause exists",
                        "doc_path": "case_law/abhimaani_structures_2025.pdf"
                    }
                    # ADD YOUR KARIBASAPPA AND OTHER TIME-BAR CASES
                ],
                "defence_points": [
                    "Special circumstances preventing timely claim - COVID-19 disruptions, system outages, bona fide belief of eligibility",
                    "Reasonable cause doctrine applies - reliance on departmental circulars or consultant advice creating confusion",
                    "Section 16(5) allows credit in specific situations despite time bar",
                    "Karnataka HC precedent (Abhimaani, Karibasappa) recognizes extension for genuine cases"
                ],
                "evidence_checklist": [
                    "Timeline documentation showing when ITC claim became apparent or feasible",
                    "Correspondence with department, consultant, or auditor",
                    "Proof of circumstances preventing timely claim (lockdown orders, system downtime logs, medical emergency)",
                    "Original invoice showing transaction within allowable period",
                    "Books of account showing contemporaneous recording"
                ],
                "success_rate": "Medium",
                "notes": "Success depends on proving special circumstances and reasonable cause. Recent Karnataka HC trend is favorable."
            },
            
            "Fake or Bogus Invoices": {
                "sections": ["16(2)(a)", "16(2)(c)"],
                "circulars": [],
                "case_law": [
                    {
                        "case": "Guru Mahesh Medicals vs. State of Karnataka (Karnataka HC, 2025)",
                        "citation": "2025 (2) TMI 104",
                        "court": "Karnataka High Court",
                        "year": 2025,
                        "outcome": "Taxpayer Favorable",
                        "ratio": "Burden of proof on department to show supply was not genuine with concrete evidence. Mere allegation in SCN is insufficient to deny ITC.",
                        "doc_path": "case_law/guru_mahesh_medicals_2025.pdf"
                    }
                    # ADD YOUR OTHER FAKE INVOICE CASES
                ],
                "defence_points": [
                    "Burden of proof lies squarely on department (Guru Mahesh Medicals precedent)",
                    "Independent verification of supply required - allegation alone is legally insufficient",
                    "Taxpayer conducted due diligence before dealing with supplier (GSTIN verification, market reputation check, past successful transactions)",
                    "Complete transaction documentation trail proves genuineness",
                    "Challenge department to produce concrete evidence of non-supply"
                ],
                "evidence_checklist": [
                    "Complete transaction trail - Purchase Order, Tax Invoice, Delivery Challan, E-way Bill, Lorry Receipt",
                    "Payment through banking channel (no cash transactions)",
                    "Stock register entries showing goods receipt with dates",
                    "Utilization records - consumption in manufacturing, stock issue slips, further sale invoices",
                    "Supplier's operational existence proof - factory photos, website, GST registration certificate, prior year financials",
                    "Due diligence documentation - GSTIN verification screenshot, supplier questionnaire"
                ],
                "success_rate": "Medium to High",
                "notes": "Very fact-dependent. Strong documentation = high success. Recent trend favors taxpayers with complete paper trail."
            },
            
            "Mismatch in GSTR-2A/2B": {
                "sections": ["16(2)(c)"],
                "circulars": [
                    "Circular 183/15/2022-GST - Para 5: ITC not deniable solely on non-reflection in auto-populated statements"
                ],
                "case_law": [
                    {
                        "case": "R.S. Marketing and Logistics (Karnataka HC, 2024)",
                        "citation": "2024 (X) TMI XXX",
                        "court": "Karnataka High Court",
                        "year": 2024,
                        "outcome": "Taxpayer Favorable",
                        "ratio": "Origin precedent establishing that ITC cannot be denied solely on non-reflection in GSTR-2A/2B. Recipient's compliance with Section 16(2) is independent of supplier's return filing.",
                        "doc_path": "case_law/rs_marketing_2024.pdf"
                    }
                    # ADD ABHIMAANI AND KARIBASAPPA AS THEY FOLLOW THIS
                ],
                "defence_points": [
                    "Circular 183/15/2022-GST explicitly clarifies ITC not deniable solely on GSTR-2A/2B non-reflection",
                    "Karnataka High Court judicial chain (R.S. Marketing → Abhimaani → Karibasappa) creates binding precedent",
                    "Recipient's Section 16(2) compliance is complete and independent of supplier's procedural lapses",
                    "Mismatch caused by supplier's error in GSTR-1 filing - not recipient's fault",
                    "Substantive right to ITC cannot be denied for third-party procedural error"
                ],
                "evidence_checklist": [
                    "Original tax invoice with all mandatory details",
                    "Proof of full compliance with Section 16(2) conditions",
                    "Explanation of mismatch - supplier error, amendment pending, system glitch",
                    "Communication with supplier to rectify GSTR-1",
                    "Copy of Circular 183/15/2022-GST",
                    "Certified copies of Karnataka HC judgments (R.S. Marketing, Abhimaani, Karibasappa)"
                ],
                "success_rate": "High",
                "notes": "Post-Circular 183 and Karnataka HC chain, this is now well-settled law in favor of taxpayers."
            }
            
            # ADD YOUR OTHER 8 CATEGORIES HERE
            # Use the same structure for each category
        }


def generate_action_plan(category: str, notice_date: str, amount: float) -> List[str]:
    """
    Generate time-sensitive action items based on category and notice details
    
    Args:
        category: Denial category
        notice_date: Date of notice (YYYY-MM-DD)
        amount: ITC amount at stake
        
    Returns:
        List of prioritized action items
    """
    from datetime import datetime, timedelta
    
    notice_dt = datetime.strptime(notice_date, "%Y-%m-%d")
    today = datetime.now()
    days_elapsed = (today - notice_dt).days
    
    # Standard reply deadline is typically 7-15 days
    reply_deadline = notice_dt + timedelta(days=15)
    days_remaining = (reply_deadline - today).days
    
    actions = []
    
    # Urgent timeline action
    if days_remaining <= 0:
        actions.append(f"⚠️ CRITICAL: Reply deadline passed! File condonation of delay application immediately")
    elif days_remaining <= 3:
        actions.append(f"🚨 URGENT: Only {days_remaining} days left to reply. Prioritize this case.")
    else:
        actions.append(f"📅 Reply deadline: {reply_deadline.strftime('%d-%b-%Y')} ({days_remaining} days remaining)")
    
    # Category-specific actions
    if category == "Supplier Non-Filing":
        actions.extend([
            "Contact supplier immediately to confirm GSTR-1 filing status",
            "Gather complete transaction documentation (invoice, payment, goods receipt)",
            "Prepare reply citing Circular 183/15/2022-GST para 5 and LGW Industries case",
            "Request personal hearing to present case law arguments"
        ])
    elif category == "Time-Barred Claims":
        actions.extend([
            "Document special circumstances that prevented timely claim",
            "Gather evidence of bona fide belief (consultant advice, circulars relied upon)",
            "Prepare detailed timeline showing when claim became apparent",
            "Cite Karnataka HC cases (Abhimaani, Karibasappa) on reasonable cause"
        ])
    elif category == "Fake or Bogus Invoices":
        actions.extend([
            "Collect complete transaction trail (PO to payment to utilization)",
            "Document supplier verification steps taken at time of transaction",
            "Prepare challenge to department's allegation - demand concrete proof",
            "Cite Guru Mahesh Medicals on burden of proof",
            "Consider requesting cross-examination of department's witnesses"
        ])
    elif category == "Mismatch in GSTR-2A/2B":
        actions.extend([
            "Contact supplier to file/amend GSTR-1 immediately",
            "Prepare reconciliation statement showing mismatch cause",
            "Reply citing Circular 183 and Karnataka HC judicial chain",
            "Attach certified copy of invoice + Section 16(2) compliance proof"
        ])
    else:
        actions.extend([
            "Review notice grounds carefully and identify all allegations",
            "Gather category-specific documentation",
            "Consult GST expert for detailed strategy",
            "Prepare comprehensive written reply with case law support"
        ])
    
    # High-value case specific action
    if amount > 500000:  # More than 5 lakhs
        actions.append(f"💰 High-value case (₹{amount:,.0f}): Consider engaging senior counsel for hearing")
    
    return actions


if __name__ == "__main__":
    # Demo usage
    db = DefenceDatabase()
    
    print("\n" + "="*80)
    print("DEFENCE DATABASE - DEMO")
    print("="*80 + "\n")
    
    print(f"Knowledge Base Statistics:")
    stats = db.get_statistics()
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    print("\n" + "-"*80 + "\n")
    
    # Get defence for Supplier Non-Filing
    strategy = db.get_defence_strategy("Supplier Non-Filing")
    
    print(f"Defence Strategy: {strategy['category']}")
    print(f"\nApplicable Sections: {', '.join(strategy['sections'])}")
    print(f"\nKey Defence Points:")
    for i, point in enumerate(strategy['defence_points'][:3], 1):
        print(f"  {i}. {point}")
    
    print(f"\nRelevant Case Law:")
    for case in strategy['case_law'][:2]:
        print(f"  • {case['case']}")
        print(f"    Ratio: {case['ratio'][:100]}...")
    
    print("\n" + "="*80)
