"""
ITC Denial Classification Engine
Uses zero-shot classification for instant categorization without training
"""

from transformers import pipeline
import torch
from typing import List, Tuple, Dict
from loguru import logger

class ITCDenialClassifier:
    """
    Classifies GST ITC denial reasons into 12 standard categories
    using zero-shot classification (no training required)
    """
    
    # 12 Standard ITC Denial Categories
    CATEGORIES = [
        "Supplier Non-Filing",
        "Time-Barred Claims",
        "Fake or Bogus Invoices",
        "Invoice Defects",
        "Mismatch in GSTR-2A/2B",
        "Blocked Credits",
        "Ineligible Inputs",
        "Reverse Charge Issues",
        "Payment Not Made to Supplier",
        "Document Unavailability",
        "Assessment or Audit Adjustments",
        "Other Complex Issues"
    ]
    
    # Category descriptions for better zero-shot accuracy
    CATEGORY_DESCRIPTIONS = {
        "Supplier Non-Filing": "supplier has not filed GST return, vendor non-compliance, supplier's GSTR-1 not filed",
        "Time-Barred Claims": "ITC claimed after time limit, beyond September deadline, Section 16(4) time bar",
        "Fake or Bogus Invoices": "fake invoice, bogus transaction, non-genuine supply, shell company",
        "Invoice Defects": "invoice missing mandatory fields, incorrect GSTIN, HSN code error",
        "Mismatch in GSTR-2A/2B": "not reflected in GSTR-2A, auto-populated statement mismatch, recipient's return discrepancy",
        "Blocked Credits": "ITC not available, blocked credit on motor vehicles, personal use items",
        "Ineligible Inputs": "exempt supply, non-business purpose, personal consumption",
        "Reverse Charge Issues": "reverse charge mechanism not followed, RCM error",
        "Payment Not Made to Supplier": "not paid within 180 days, payment proof missing",
        "Document Unavailability": "supporting documents not provided, goods receipt proof absent",
        "Assessment or Audit Adjustments": "officer disallowed during audit, scrutiny assessment adjustment",
        "Other Complex Issues": "multiple grounds, hybrid issues, complex scenario"
    }
    
    def __init__(self, model_name: str = "facebook/bart-large-mnli"):
        """
        Initialize classifier with pre-trained zero-shot model
        
        Args:
            model_name: HuggingFace model for zero-shot classification
                       Default: BART (best for legal text)
        """
        logger.info(f"Loading classifier model: {model_name}")
        
        device = 0 if torch.cuda.is_available() else -1
        logger.info(f"Using device: {'GPU' if device == 0 else 'CPU'}")
        
        self.classifier = pipeline(
            "zero-shot-classification",
            model=model_name,
            device=device
        )
        
        logger.success("Classifier loaded successfully")
    
    def classify(
        self, 
        denial_text: str, 
        top_k: int = 2,
        threshold: float = 0.3
    ) -> List[Tuple[str, float]]:
        """
        Classify denial text into categories
        
        Args:
            denial_text: The denial reason text from notice
            top_k: Number of top categories to return
            threshold: Minimum confidence score (0-1)
        
        Returns:
            List of (category, confidence_score) tuples
            
        Example:
            >>> classifier.classify("ITC denied as supplier not filed GSTR-1")
            [('Supplier Non-Filing', 0.89), ('Mismatch in GSTR-2A/2B', 0.34)]
        """
        if not denial_text or len(denial_text.strip()) < 10:
            logger.warning("Denial text too short or empty")
            return [("Other Complex Issues", 0.5)]
        
        logger.info(f"Classifying: {denial_text[:100]}...")
        
        try:
            # Perform zero-shot classification
            result = self.classifier(
                denial_text,
                self.CATEGORIES,
                multi_label=True  # Allow multiple applicable categories
            )
            
            # Extract top-k categories above threshold
            top_categories = [
                (label, score)
                for label, score in zip(result['labels'], result['scores'])
                if score > threshold
            ][:top_k]
            
            if not top_categories:
                # If no category meets threshold, return top 1 anyway
                top_categories = [(result['labels'][0], result['scores'][0])]
            
            logger.success(f"Classification complete: {top_categories[0][0]} ({top_categories[0][1]:.2f})")
            
            return top_categories
            
        except Exception as e:
            logger.error(f"Classification failed: {str(e)}")
            return [("Other Complex Issues", 0.5)]
    
    def classify_with_explanation(self, denial_text: str) -> Dict:
        """
        Classify with detailed explanation of why categories were chosen
        
        Returns:
            {
                'primary_category': str,
                'confidence': float,
                'all_scores': Dict[str, float],
                'reasoning': str
            }
        """
        result = self.classifier(denial_text, self.CATEGORIES, multi_label=True)
        
        # Create explanation based on matched keywords
        primary_cat = result['labels'][0]
        matched_keywords = []
        
        denial_lower = denial_text.lower()
        for keyword in self.CATEGORY_DESCRIPTIONS[primary_cat].split(', '):
            if keyword.lower() in denial_lower:
                matched_keywords.append(keyword)
        
        reasoning = f"Classified as '{primary_cat}' based on keywords: {', '.join(matched_keywords)}" if matched_keywords else \
                   f"Semantic similarity suggests '{primary_cat}'"
        
        return {
            'primary_category': primary_cat,
            'confidence': result['scores'][0],
            'all_scores': dict(zip(result['labels'], result['scores'])),
            'reasoning': reasoning
        }
    
    def batch_classify(self, denial_texts: List[str]) -> List[List[Tuple[str, float]]]:
        """
        Classify multiple denials at once (faster for bulk processing)
        
        Args:
            denial_texts: List of denial reason texts
            
        Returns:
            List of classification results, one per input text
        """
        logger.info(f"Batch classifying {len(denial_texts)} texts")
        
        results = []
        for text in denial_texts:
            results.append(self.classify(text))
        
        return results
    
    def get_category_info(self, category: str) -> Dict:
        """
        Get detailed information about a category
        
        Returns category description and example keywords
        """
        return {
            'name': category,
            'description': self.CATEGORY_DESCRIPTIONS.get(category, "No description available"),
            'keywords': self.CATEGORY_DESCRIPTIONS.get(category, "").split(', ')
        }


# Convenience function for quick classification
def quick_classify(denial_text: str) -> str:
    """
    Quick single-use classification (creates new classifier instance)
    For repeated use, create a classifier instance instead
    
    Returns:
        Primary category name
    """
    classifier = ITCDenialClassifier()
    result = classifier.classify(denial_text, top_k=1)
    return result[0][0]


if __name__ == "__main__":
    # Demo usage
    classifier = ITCDenialClassifier()
    
    # Test cases
    test_cases = [
        "ITC claim denied as supplier has not filed GSTR-1 for the relevant tax period",
        "Credit claimed beyond time limit prescribed under Section 16(4) of CGST Act",
        "Invoice does not contain mandatory details as required under Section 16(2)",
        "Transaction appears to be fake based on department investigation"
    ]
    
    print("\n" + "="*80)
    print("ITC DENIAL CLASSIFIER - DEMO")
    print("="*80 + "\n")
    
    for i, text in enumerate(test_cases, 1):
        print(f"Test Case {i}:")
        print(f"Denial Text: {text}")
        
        results = classifier.classify(text, top_k=2)
        
        print(f"Primary Category: {results[0][0]} (confidence: {results[0][1]:.2%})")
        if len(results) > 1:
            print(f"Secondary Category: {results[1][0]} (confidence: {results[1][1]:.2%})")
        
        print("-" * 80 + "\n")
